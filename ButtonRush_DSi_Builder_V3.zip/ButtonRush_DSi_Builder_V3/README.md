# Button Rush DSi Builder V3

Builder mobile para projetos Nintendo DS/DSi em C + Makefile.

## O que a V3 faz

1. Você envia um `.zip` pelo celular.
2. O servidor procura um `Makefile`.
3. O próprio container usa `devkitpro/devkitarm`, sem instalação manual de devkitARM no servidor.
4. Executa `make`.
5. Encontra o `.nds` gerado e oferece o download.

A imagem `devkitpro/devkitarm` é publicada pelo devkitPro e é destinada ao desenvolvimento GBA/DS/3DS.

## Rodar localmente

Se o computador tiver Docker:

```bash
docker build -t buttonrush-builder .
docker run --rm -p 7700:10000 buttonrush-builder
```

Abra `http://localhost:7700`.

## Hospedar

O projeto inclui `render.yaml` para serviços Docker. Em uma plataforma que aceite Docker, basta publicar este repositório e usar a porta definida pela variável `PORT`.

## Estrutura esperada do ZIP do jogo

```text
MeuJogo/
  Makefile
  source/
    main.c
```

O Makefile deve ser compatível com devkitARM/devkitPro para Nintendo DS. Exemplos oficiais usam `include $(DEVKITARM)/ds_rules` e geram o `.nds` com as regras do devkitPro.

## Limitações

- Limite de upload: 50 MB.
- Uma compilação por requisição.
- O Builder compila projetos NDS existentes; ele não converte HTML/CSS/JS automaticamente em C.
