import os, re, shutil, subprocess, tempfile, zipfile, uuid
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file

app = Flask(__name__)
BASE = Path('/tmp/buttonrush-builder')
BASE.mkdir(parents=True, exist_ok=True)
MAX_UPLOAD = 50 * 1024 * 1024
TIMEOUT = 300


def safe_extract(zf, dest):
    root = dest.resolve()
    for info in zf.infolist():
        name = info.filename.replace('\\', '/')
        if name.startswith('/') or '..' in Path(name).parts:
            raise ValueError('ZIP inválido: caminho inseguro.')
        target = (dest / name).resolve()
        if not str(target).startswith(str(root) + os.sep) and target != root:
            raise ValueError('ZIP inválido: caminho inseguro.')
    zf.extractall(dest)


def find_project(root):
    makefiles = list(root.rglob('Makefile'))
    if not makefiles:
        return None
    # Prefer the Makefile with a nearby source directory.
    makefiles.sort(key=lambda p: (0 if (p.parent/'source').exists() else 1, len(p.parts)))
    return makefiles[0].parent


def run_build(project, log_file):
    env = os.environ.copy()
    env.setdefault('DEVKITPRO', '/opt/devkitpro')
    env.setdefault('DEVKITARM', '/opt/devkitpro/devkitARM')
    # ds_rules and devkitPro packages use these locations.
    proc = subprocess.run(
        ['make', '-j2'], cwd=project, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, timeout=TIMEOUT
    )
    log_file.write_text(proc.stdout, encoding='utf-8', errors='replace')
    return proc.returncode, proc.stdout


@app.get('/')
def index():
    return render_template('index.html')

@app.get('/api/health')
def health():
    checks = {}
    for cmd in ['make', 'arm-none-eabi-gcc', 'ndstool']:
        try:
            p = subprocess.run([cmd, '--version'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=5)
            checks[cmd] = p.returncode == 0
        except Exception:
            checks[cmd] = False
    return jsonify({'ok': all(checks.values()), 'checks': checks, 'devkitpro': os.environ.get('DEVKITPRO'), 'devkitarm': os.environ.get('DEVKITARM')})

@app.post('/api/build')
def build():
    uploaded = request.files.get('project')
    if not uploaded or not uploaded.filename.lower().endswith('.zip'):
        return jsonify({'ok': False, 'error': 'Envie um arquivo .zip de um projeto NDS com Makefile.'}), 400
    data = uploaded.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD:
        return jsonify({'ok': False, 'error': 'ZIP muito grande. Limite: 50 MB.'}), 413

    job_id = uuid.uuid4().hex
    job = BASE / job_id
    src = job / 'src'
    out = job / 'out'
    job.mkdir(); src.mkdir(); out.mkdir()
    zip_path = job / 'project.zip'
    zip_path.write_bytes(data)
    log_path = job / 'build.log'
    try:
        with zipfile.ZipFile(zip_path) as zf:
            safe_extract(zf, src)
        project = find_project(src)
        if not project:
            return jsonify({'ok': False, 'error': 'Não encontrei um Makefile no ZIP.'}), 400
        rc, log = run_build(project, log_path)
        nds = sorted(project.rglob('*.nds'), key=lambda p: p.stat().st_mtime, reverse=True)
        if rc != 0 or not nds:
            tail = log[-12000:] if log else 'Sem saída do compilador.'
            return jsonify({'ok': False, 'error': 'A compilação falhou.', 'log': tail}), 422
        artifact = out / 'ButtonRush.nds'
        shutil.copy2(nds[0], artifact)
        return jsonify({'ok': True, 'message': 'Compilação concluída!', 'job': job_id, 'file': f'/api/download/{job_id}'})
    except subprocess.TimeoutExpired:
        return jsonify({'ok': False, 'error': 'A compilação demorou mais de 5 minutos e foi interrompida.'}), 408
    except zipfile.BadZipFile:
        return jsonify({'ok': False, 'error': 'O arquivo enviado não é um ZIP válido.'}), 400
    except Exception as e:
        return jsonify({'ok': False, 'error': f'Erro no Builder: {e}'}), 500
    finally:
        zip_path.unlink(missing_ok=True)

@app.get('/api/download/<job_id>')
def download(job_id):
    if not re.fullmatch(r'[0-9a-f]{32}', job_id):
        return 'ID inválido', 400
    artifact = BASE / job_id / 'out' / 'ButtonRush.nds'
    if not artifact.exists():
        return 'Arquivo não encontrado', 404
    return send_file(artifact, as_attachment=True, download_name='ButtonRush.nds', mimetype='application/octet-stream')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', '7700')))
